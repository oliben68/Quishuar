var __content__ = {}

__content__.languages = [{
        "id": "fr",
        "busy-msg": "Veuillez attendre s'il vous plait",
        "language-selector": {
            "name": "Français",
            "description": "langue française",
            "flag": "/images/flags/fr.png",
            "label": "selecteur de langue"
        }
    }, {
        "id": "es",
        "busy-msg": "Veuillez attendre s'il vous plait",
        "language-selector": {
            "name": "Español",
            "description": "idioma español",
            "flag": "/images/flags/es.png",
            "label": "selector de idioma"
        }
    }, {
        "id": "en",
        "busy-msg": "Please wait",
        "language-selector": {
            "name": "English",
            "description": "english language",
            "flag": "/images/flags/gb.png",
            "label": "language selector"
        },
    }, {
        "id": "qu",
        "busy-msg": "Veuillez attendre s'il vous plait",
        "language-selector": {
            "name": "Quechua",
            "description": "idioma quechua",
            "flag": "/images/flags/pf.png",
            "label": "selector de idioma"
        },
    }];
